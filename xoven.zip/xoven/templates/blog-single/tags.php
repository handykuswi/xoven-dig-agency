<div class="post-tag-box">
	<div class="title">
		<h6><?php esc_html_e( 'Tags :', 'xoven' ); ?></h6>
	</div>
	<div class="tag-box">
		<ul>
			<li><?php the_tags(' ', '<span class="commax">,</span>  ', ''); ?></li>
		</ul>
	</div>
</div>