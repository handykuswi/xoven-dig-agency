<?php
/**
 * Single Post Content Template
 *
 * @package    WordPress
 * @subpackage XOVEN
 * @author     Theme Kalia
 * @version    1.0
 */
?>
<?php global $wp_query;

$options = xoven_WSH()->option();
$allowed_html = wp_kses_allowed_html();

$page_id = ( $wp_query->is_posts_page ) ? $wp_query->queried_object->ID : get_the_ID();

$gallery = get_post_meta( $page_id, 'xoven_gallery_images', true );

$video = get_post_meta( $page_id, 'xoven_video_url', true );


$audio_type = get_post_meta( $page_id, 'xoven_audio_type', true );

?>


<div class="blog-details-content">
	<div class="single-blog-style1 wow fadeInUp" data-wow-duration="1500ms">
	
		<?php if(!$options->get('single_post_thumb' ) ): ?>	
		<div class="img-holder">
			<div class="inner">
				<?php the_post_thumbnail(); ?>
			</div>
		</div>
		<?php endif; ?>
		
		<div class="text-holder">
			<div class="meta-box">
				<ul class="meta-info">
					<?php if(!$options->get('single_post_comments' ) ): ?>
					<li><i class="fa fa-comments-o" aria-hidden="true"></i><?php comments_number(); ?></li>
					<?php endif;?>
					
					<?php if(!$options->get('single_post_author' ) ): ?>
					<li><a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta('ID') )); ?>"><?php the_author(); ?></a></li>
					<?php endif;?>
				</ul>
			</div>
			
		</div> 
	</div>

	<div class="text post_con_divider">
		<?php the_content(); ?>
		<div class="clearfix"></div>
		<?php wp_link_pages(array('before'=>'<div class="paginate_links">'.esc_html__('Pages: ', 'xoven'), 'after' => '</div>', 'link_before'=>'', 'link_after'=>'')); ?>
	</div>
	
	<?php if(!$options->get('single_post_tag' ) ): ?>
	<?php xoven_template_load( 'templates/blog-single/tags.php', compact( 'options', 'data' ) ); ?>
	<?php endif;?>

	<?php comments_template(); ?>  





</div>