<?php 
get_header();
$options = xoven_WSH()->option(); ?>



<section class="search_area_df centred">
	<div class="container">
		<div class="inner-box">
			<figure class="error-image p_relative d_block mb_70">
				<img src="<?php echo esc_url(get_template_directory_uri().'/assets/images/search.png');?>" alt="<?php echo wp_kses( $options->get( '404_title'), $allowed_html ); ?>">
			</figure>
			
			
			<?php if($options->get('search_page_title' ) ): ?>
			<h2 class="d_block fs_50 lh_60 fw_bold mb_12"><?php echo wp_kses( $options->get( 'search_page_title'), $allowed_html ); ?></h2>
			
			<?php else : ?>
			
			<h2 class="d_block fs_50 lh_60 fw_bold mb_12"><?php esc_html_e( 'Oops! Search not Found', 'xoven' ); ?></h2>
			
			<?php endif; ?>	
			
			<?php if($options->get('search_page_text' ) ): ?>
			<h3 class="d_block fs_24 fw_medium mb_55"><?php echo(wp_kses($options->get('search_page_text' ), $allowed_html )) ?></h3>
			<?php else : ?>
			<h3 class="d_block fs_24 fw_medium mb_55"><?php esc_html_e( 'The page you are looking for not found.', 'xoven' ); ?></h3>
			<?php endif; ?>	
			
			
			
			
			<div class="error_btn1 btn-box wow fadeInUp animated" data-wow-delay="300ms">
				<a href="<?php echo esc_url(home_url('/')); ?>" class="btn-one"><i class="fas fa-feather"></i>
				<?php esc_html_e( 'Back To Home', 'xoven' ); ?>
				</a>
			</div>
			
			<br><br>
			<div class="searchpage_form">
				<?php echo get_search_form(); ?>
			</div>
		</div>
	</div>
</section>