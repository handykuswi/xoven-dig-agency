<?php
$options = xoven_WSH()->option();
$allowed_html = wp_kses_allowed_html();

/**
 * Blog Content Template
 *
 * @package    WordPress
 * @subpackage XOVEN
 * @author     Theme Kalia
 * @version    1.0
 */

if ( class_exists( 'Xoven_Resizer' ) ) {
	$img_obj = new Xoven_Resizer();
} else {
	$img_obj = array();
}
$allowed_tags = wp_kses_allowed_html('post');
global $post;
?>
<div <?php post_class(); ?>>

<div class="single-blog-style1 wow fadeInUp" data-wow-duration="1500ms">

	<?php if ( has_post_thumbnail() ) { ?>
	<div class="img-holder">
		<div class="inner">
			<?php the_post_thumbnail(); ?>
		</div>
	</div>
	<?php } ?>
	
	<div class="text-holder">
		<h3 class="blog-title">
			<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a>
		</h3>
		<div class="text">
			<?php the_excerpt(); ?>
		</div>
		<div class="bottom-box">
		
		
			<?php if(!$options->get('blog_post_readmore' ) ): ?>						
			<?php if($options->get('blog_post_readmoretext' ) ): ?>	

			<div class="btns-box">
				<a class="btn-one" href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
					<div class="border_line"></div>
					<div class="left_round"></div>
					<div class="right_round"></div>
					<span class="txt"><?php echo wp_kses( $options->get( 'blog_post_readmoretext'), $allowed_html ); ?><i class="flaticon-plus-1 plusicon"></i></span>
				</a>
			</div>
			
			<?php else: ?>		
			
			<div class="btns-box">
				<a class="btn-one" href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
					<div class="border_line"></div>
					<div class="left_round"></div>
					<div class="right_round"></div>
					<span class="txt"><?php esc_html_e('Read More', 'xoven');?><i class="flaticon-plus-1 plusicon"></i></span>
				</a>
			</div>
			
			<?php endif; ?>	
			<?php endif;?>
			
			<div class="meta-box">
				<ul class="meta-info">
					<?php if(!$options->get('blog_post_comments' ) ): ?>
					<li><i class="fa fa-comments-o" aria-hidden="true"></i><?php comments_number(); ?></li>
					<?php endif;?>
					
					<?php if(!$options->get('blog_post_author' ) ): ?>
					<li><a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta('ID') )); ?>"><?php the_author(); ?></a></li>
					<?php endif;?>
				</ul>
			</div>
		</div>
	</div> 
</div>


</div>