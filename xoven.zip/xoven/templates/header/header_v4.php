<?php
$options = xoven_WSH()->option(); 
$allowed_html = wp_kses_allowed_html( 'post' );

//Logo Settings
$image_logo = $options->get( 'image_normal_logo' );
$logo_dimension = $options->get( 'normal_logo_dimension' );

$image_logo2 = $options->get( 'image_normal_logo2' );
$logo_dimension2 = $options->get( 'normal_logo_dimension2' );

$image_logo3 = $options->get( 'image_normal_logo3' );
$logo_dimension3 = $options->get( 'normal_logo_dimension3' );

$logo_type = '';
$logo_text = '';
$logo_typography = '';
?>

<!-- Main header-->
<header class="main-header header-style-three">
    <!--Start Header--> 
    <div class="header-three clearfix">
        <div class="auto-container clearfix">
            <div class="outer-box clearfix">
                <div class="header-three_left">

                    <div class="logo">
                        <?php echo xoven_logo( $logo_type, $image_logo, $logo_dimension, $logo_text, $logo_typography ); ?>
                    </div>

                    <div class="nav-outer style3 clearfix">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler">
                            <div class="inner">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </div>
                        </div>
                        <!-- Main Menu -->
                        <nav class="main-menu style3 navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                <ul class="navigation clearfix">
                                    <?php wp_nav_menu( array( 'theme_location' => 'onepage_menu', 'container_id' => 'navbarSupportedContent',
									'container_class'=>'collapse navbar-collapse sub-menu-bar',
									'menu_class'=>'nav navbar-nav',
									'fallback_cb'=>false, 
									'add_li_class'  => 'nav-item',
									'items_wrap' => '%3$s', 
									'container'=>false,
									'depth'=>'3',
									'walker'=> new Bootstrap_walker()  
									) ); ?>
                                </ul>
                            </div>
                        </nav>                        
                        <!-- Main Menu End-->
                    </div> 

                </div>

                <div class="header-three_right">
				
					<?php if( $options->get( 'phone_v4')):?>
				
                    <div class="header-contact-info">
                        <div class="icon">
                            <img src="<?php echo esc_url(get_template_directory_uri().'/assets/images/icon/chat.png');?>" alt="">
                        </div>
                        <div class="title">
                            <h5><?php echo wp_kses( $options->get( 'phone_title_v4'), $allowed_html ); ?></h5>
                            <h3><a href="tel:<?php echo wp_kses( $options->get( 'phone_link_v4'), $allowed_html ); ?>"><?php echo wp_kses( $options->get( 'phone_v4'), $allowed_html ); ?></a></h3>
                        </div>
                    </div>
					
					<?php endif; ?>	


					<?php if( $options->get( 'button_show_v4' ) ):?>
					<?php if( $options->get( 'button_v4')):?>
                    <div class="btns-box">
                        <a class="btn-one" href="<?php echo wp_kses( $options->get( 'button_link_v4'), $allowed_html ); ?>">
                            <div class="border_line"><img src="<?php echo esc_url(get_template_directory_uri().'/assets/images/shape/button-border.png');?>" alt=""></div>
                            <span class="txt"><?php echo wp_kses( $options->get( 'button_v4'), $allowed_html ); ?><i class="flaticon-plus-1 plusicon"></i></span>
                        </a>
                    </div>
					<?php endif; ?>
					<?php endif; ?>
					

                </div>

            </div>
        </div>    
    </div> 
    <!--End header-->

    <!--Sticky Header-->
    <div class="sticky-header">
        <div class="container">
            <div class="clearfix">
                <!--Logo-->
                <div class="logo float-left">
                    <div class="img-responsive">
					
					<?php echo xoven_logo( $logo_type, $image_logo2, $logo_dimension2, $logo_text, $logo_typography ); ?>
					
					</div>
                </div>
                <!--Right Col-->
                <div class="right-col float-right">
                    <!-- Main Menu -->
                    <nav class="main-menu clearfix">
                    <!--Keep This Empty / Menu will come through Javascript-->
                    </nav>   
                </div>
            </div>
        </div>
    </div>
    <!--End Sticky Header-->
    
    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <div class="close-btn"><span class="icon fa fa-times-circle"></span></div>
        <nav class="menu-box">
            <div class="nav-logo">
			<?php echo xoven_logo( $logo_type, $image_logo3, $logo_dimension3, $logo_text, $logo_typography ); ?>
			</div>
            <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
			
			<?php if( $options->get( 'header_social_show_v4' ) ):?>

			
            <!--Social Links-->
            <div class="social-links">
                <?php
					$icons = $options->get( 'header_social_v4' );
					if ( ! empty( $icons ) ) :
				?>
                <ul class="clearfix">
					<?php
					foreach ( $icons as $h_icon ) :
					$header_social_icons = json_decode( urldecode( xoven_set( $h_icon, 'data' ) ) );
					if ( xoven_set( $header_social_icons, 'enable' ) == '' ) {
						continue;
					}
					$icon_class = explode( '-', xoven_set( $header_social_icons, 'icon' ) );
					?>
                    <li><a href="<?php echo esc_url(xoven_set( $header_social_icons, 'url' )); ?>"><span class="fab fa <?php echo esc_attr( xoven_set( $header_social_icons, 'icon' ) ); ?>"></span></a></li>
					<?php endforeach; ?>
                </ul>
				<?php endif; ?>
            </div>
			
			<?php endif; ?>
			
        </nav>
    </div>
    <!-- End Mobile Menu --> 
</header>