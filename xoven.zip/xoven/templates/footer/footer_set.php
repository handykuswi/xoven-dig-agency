<?php
/**
 * Footer Template  File
 *
 * @package XOVEN
 * @author  Theme Kalia
 * @version 1.0
 */

$options = xoven_WSH()->option();
$allowed_html = wp_kses_allowed_html( 'post' );
?>

	<footer class="footer-area widgets">
		<div class="footer-area_bg" style="background-image: url(<?php echo esc_url(get_template_directory_uri().'/assets/images/parallax-background/footer-area_bg.jpg');?>);"></div>
		<div class="shape">
			<img src="<?php echo esc_url(get_template_directory_uri().'/assets/images/shape/thm-shape-4.png');?>" alt="">
		</div>
        <?php if ( is_active_sidebar( 'footer-sidebar' ) ) { ?>
        <div class="auto-container">
            <!--Widgets Section-->
            <div class="widgets-section">
                <div class="row clearfix">
                    <?php dynamic_sidebar( 'footer-sidebar' ); ?>
                </div>
            </div>
        </div>
        <?php } ?>           
    </footer>


