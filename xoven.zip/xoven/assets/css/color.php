<?php


/** Set ABSPATH for execution */
define( 'ABSPATH', dirname(dirname(__FILE__)) . '/' );
define( 'WPINC', 'wp-includes' );


/**
 * @ignore
 */
function add_filter() {}

/**
 * @ignore
 */
function esc_attr($str) {return $str;}

/**
 * @ignore
 */
function apply_filters() {}

/**
 * @ignore
 */
function get_option() {}

/**
 * @ignore
 */
function is_lighttpd_before_150() {}

/**
 * @ignore
 */
function add_action() {}

/**
 * @ignore
 */
function did_action() {}

/**
 * @ignore
 */
function do_action_ref_array() {}

/**
 * @ignore
 */
function get_bloginfo() {}

/**
 * @ignore
 */
function is_admin() {return true;}

/**
 * @ignore
 */
function site_url() {}

/**
 * @ignore
 */
function admin_url() {}

/**
 * @ignore
 */
function home_url() {}

/**
 * @ignore
 */
function includes_url() {}

/**
 * @ignore
 */
function wp_guess_url() {}

if ( ! function_exists( 'json_encode' ) ) :
/**
 * @ignore
 */
function json_encode() {}
endif;



/* Convert hexdec color string to rgb(a) string */
 
function hex2rgba($color, $opacity = false) {
 
	$default = 'rgb(0,0,0)';
 
	//Return default if no color provided
	if(empty($color))
          return $default; 
 
	//Sanitize $color if "#" is provided 
        if ($color[0] == '#' ) {
        	$color = substr( $color, 1 );
        }
 
        //Check if color has 6 or 3 characters and get values
        if (strlen($color) == 6) {
                $hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
        } elseif ( strlen( $color ) == 3 ) {
                $hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
        } else {
                return $default;
        }
 
        //Convert hexadec to rgb
        $rgb =  array_map('hexdec', $hex);
 
        //Check if opacity is set(rgba or rgb)
        if($opacity){
        	if(abs($opacity) > 1)
        		$opacity = 1.0;
        	$output = 'rgba('.implode(",",$rgb).','.$opacity.')';
        } else {
        	$output = 'rgb('.implode(",",$rgb).')';
        }
 
        //Return rgb(a) color string
        return $output;
}

$color = $_GET['main_color'];

ob_start(); ?>



/*** 
=====================================================
	Theme Main Color Css
=====================================================
***/

.main-menu .navigation>li:hover>a, .main-menu .navigation>li.current>a,
.main-menu .navigation> li> ul> li> a:hover,
.slider-contact-info .title h3 a:hover,
.main-slider .banner-carousel.owl-carousel button.owl-dot.active:before,
.partner-area .partner-title h2 span,
.single-service-style1 .title h3 a:hover,
.sec-title .sub-title h3,
.xoven-video-gallery-2 .big-title h2 span,
.single-team-style1 .title-holder .title h3 a:hover,
.single-team-style1 .title-holder .social-links ul li a,
.single-blog-style1 .text-holder .blog-title a:hover,
.single-blog-style1 .text-holder .meta-box .meta-info li a:hover,
.footer-top .inner .text h6,
.single-footer-widget .bottom-box ul li a:hover

{
	color:#<?php echo esc_attr( $color ); ?>!important;
}


/*** 
=====================================================
	Theme Main Background Color Css
=====================================================
***/

.btn-one:after,
.header-social-link-1 ul li a:before,
.header-social-link-1 ul li a:hover,
.scroll-top,
.single-service-style1 .title .inner-text:before,
.xoven-video-galler-1,
.single-portfolio-style1 .img-holder .overlay-icon a,
.xoven-video-gallery-2 .icon a,
.skill-style1_image-box-outer .title,
.skill-style1_image-box-outer .title:before,
.skill-style1_image-box-outer .title:after,
.progress-levels .progress-box .bar .bar-fill,
.single-fact-counter .title,
.testimonial-style1-area,
.copyright-text,
.single-footer-widget .title::before,
.single-footer-widget .instagram-box li .overlay

{
	background: #<?php echo esc_attr( $color ); ?>!important;
	background-color:#<?php echo esc_attr( $color ); ?>!important;
}


/************** border-color***************/

.single-team-style1 .title-holder .social-links ul li a,
.single-fact-counter:hover .border-box

{
	border-color:#<?php echo esc_attr( $color ); ?>!important;
}

/* ------------------////End of Section////--------------*/


/************** outline-color***************/



/* ------------------////End of Section////--------------*/




<?php 

$out = ob_get_clean();
$expires_offset = 31536000; // 1 year
header('Content-Type: text/css; charset=UTF-8');
header('Expires: ' . gmdate( "D, d M Y H:i:s", time() + $expires_offset ) . ' GMT');
header("Cache-Control: public, max-age=$expires_offset");
header('Vary: Accept-Encoding'); // Handle proxies
header('Content-Encoding: gzip');

echo gzencode($out);
exit;