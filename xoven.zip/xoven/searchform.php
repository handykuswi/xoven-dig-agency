<?php
/**
 * Search Form template
 *
 * @package XOVEN
 * @author Theme Kalia
 * @version 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}
?>


<div class="single-sidebar_search_box">
	<div class="sidebar-search-box">
		<form method="get" class="search-form">
			<input name="s" placeholder="<?php echo esc_attr__( 'Search Your Keywords...', 'xoven' ); ?>" type="text">
			<button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
		</form>
	</div>
</div>