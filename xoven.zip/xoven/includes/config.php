<?php
/**
 * Theme config file.
 *
 * @package XOVEN
 * @author  ThemeKalia
 * @version 1.0
 * changed
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}

$config = array();

$config['default']['xoven_main_header'][] 	= array( 'xoven_preloader', 98 );
$config['default']['xoven_main_header'][] 	= array( 'xoven_main_header_area', 99 );

$config['default']['xoven_main_footer'][] 	= array( 'xoven_preloader', 98 );
$config['default']['xoven_main_footer'][] 	= array( 'xoven_main_footer_area', 99 );

$config['default']['xoven_sidebar'][] 	    = array( 'xoven_sidebar', 99 );

$config['default']['xoven_banner'][] 	    = array( 'xoven_banner', 99 );


return $config;
