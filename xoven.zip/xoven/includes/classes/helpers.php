<?php

namespace XOVEN\Includes\Classes;


/**
 * Header and Enqueue class
 */
class Helpers {


	function __construct() {

	}

	/**
	 * Hook up main headers with different header styles
	 *
	 * @return void This function returns nothing.
	 */
	function header() {

		
	    
	}


}

