<?php

namespace XOVEN\Includes\Classes;


/**
 * Header and Enqueue class
 */
class Header_Enqueue {


	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );

		add_filter( 'wp_resource_hints', array( __CLASS__, 'resource_hints' ), 10, 2 );
	}

	/**
	 * Gets the arrays from method scripts and styles and process them to load.
	 * Styles are being loaded by default while scripts only enqueue and can be loaded where required.
	 *
	 * @return void This function returns nothing.
	 */
	public static function enqueue() {

		self::scripts();

		self::styles();

	}

	/**
	 * The major scripts loader to load all the scripts of the theme. Developer can hookup own scripts.
	 * All the scripts are being load in footer.
	 *
	 * @return array Returns the array of scripts to load
	 */
	public static function scripts() {
		$options = get_theme_mod( XOVEN_NAME . '_options-mods' );
		$ssl     = is_ssl() ? 'https' : 'http';

		$scripts = array(
			'jquery'         => 'assets/js/jquery.js',
			'bootstrap-bundle-min'         => 'assets/js/bootstrap.bundle.min.js',
			'bootstrap-select-min'         => 'assets/js/bootstrap-select.min.js',
			'owl'         => 'assets/js/owl.js',
			'aos'         => 'assets/js/aos.js',
			'appear'         => 'assets/js/appear.js',
			'bxslider-min'         => 'assets/js/bxslider.min.js',
			'html5shiv'         => 'assets/js/html5shiv.js',
			'isotope'         => 'assets/js/isotope.js',
			'jquery-countTo'         => 'assets/js/jquery.countTo.js',
			'jquery-easing-min'         => 'assets/js/jquery.easing.min.js',
			'fancybox'         => 'assets/js/jquery.fancybox.js',
			'jquery-magnific-popup-min'         => 'assets/js/jquery.magnific-popup.min.js',
			'jquery-paroller-min'         => 'assets/js/jquery.paroller.min.js',
			'jquery-ui'         => 'assets/js/jquery-ui.js',
			'knob'         => 'assets/js/knob.js',
			'pagenav'         => 'assets/js/pagenav.js',
			'parallax-min'         => 'assets/js/parallax.min.js',
			'scrollbar'         => 'assets/js/scrollbar.js',
			'TweenMax-min'         => 'assets/js/TweenMax.min.js',
			'wow'         => 'assets/js/wow.js',
			'parallax-scroll'         => 'assets/js/parallax-scroll.js',
			'plugins'         => 'assets/js/plugins.js',
			
			
			'main-script'      		=> 'assets/js/custom.js',
			
			
			//Temp
			//'jquery-cookie'      		=> 'assets/temp/jquery.cookie.js',
			//'themepanel'      		=> 'assets/temp/themepanel.js',
			
		);

		$scripts = apply_filters( 'XOVEN/includes/classes/header_enqueue/scripts', $scripts );
		/**
		 * Enqueue the scripts
		 *
		 * @var array
		 */
		foreach ( $scripts as $name => $js ) {

			if ( strstr( $js, 'http' ) || strstr( $js, 'https' ) || strstr( $js, 'googleapis.com' ) ) {

				wp_register_script( "{$name}", $js, '', '', true );
			} else {
				wp_register_script( "{$name}", get_template_directory_uri() . '/' . $js, '', '', true );
			}
		}

		wp_enqueue_script( array(
			'jquery',
			'bootstrap-bundle-min',
			'bootstrap-select-min',
			'owl',
			'aos',
			'appear',
			'bxslider-min',
			'html5shiv',
			'isotope',
			'jquery-countTo',
			'jquery-easing-min',
			'fancybox',
			'jquery-magnific-popup-min',
			'jquery-paroller-min',
			'jquery-ui',
			'knob',
			'pagenav',
			'parallax-min',
			'scrollbar',
			'TweenMax-min',
			'wow',
			'parallax-scroll',
			'plugins',
			'main-script',
			//'jquery-cookie',
			//'themepanel',
		) );


		$header_data = array(
			'ajaxurl' => esc_url( admin_url( 'admin-ajax.php' ) ),
			'nonce'   => wp_create_nonce( XOVEN_NONCE ),
		);

		wp_localize_script( 'jquery', 'xoven_data', $header_data );

		if ( xoven_set( $options, 'footer_js' ) ) {

			wp_add_inline_script( 'jquery', xoven_set( $options, 'footer_js' ) );
		}

	}

	/**
	 * The major styles loader to load all the styles of the theme. Developer can hookup own styles.
	 * All the styles are being load in head.
	 *
	 * @return array Returns the array of styles to load
	 */
	public static function styles() {
		$options     = xoven_WSH()->option();
		$header_meta = get_post_meta( get_the_ID(), 'header_style_settings');
		$header_option = $options->get( 'header_style_settings' );
		$header = ( $header_meta ) ? $header_meta['0'] : $header_option;
		
		
		$styles = array(
			'google-fonts'      => self::fonts_url(),
			'bootstrap.min'      => 'assets/css/bootstrap.min.css',
			'bootstrap-select-min'      => 'assets/css/bootstrap-select.min.css',
			'animate'      => 'assets/css/animate.css',
			'aos'      => 'assets/css/aos.css',
			'bxslider'      => 'assets/css/bxslider.css',
			'custom-animate'      => 'assets/css/custom-animate.css',
			'fancybox-min'      => 'assets/css/fancybox.min.css',
			'flaticon'      => 'assets/css/flaticon.css',
			'font-awesome-min'      => 'assets/css/font-awesome.min.css',
			'imp'      => 'assets/css/imp.css',
			'jquery-ui'      => 'assets/css/jquery-ui.css',
			'magnific-popup'      => 'assets/css/magnific-popup.css',
			'owl'      => 'assets/css/owl.css',
			'scrollbar'      => 'assets/css/scrollbar.css',
			
			'about-section'      => 'assets/css/module-css/about-section.css',
			'banner-section'      => 'assets/css/module-css/banner-section.css',
			'blog-section'      => 'assets/css/module-css/blog-section.css',
			'breadcrumb-section'      => 'assets/css/module-css/breadcrumb-section.css',
			'contact-page'      => 'assets/css/module-css/contact-page.css',
			'fact-counter-section'      => 'assets/css/module-css/fact-counter-section.css',
			'faq-section'      => 'assets/css/module-css/faq-section.css',
			'footer-section'      => 'assets/css/module-css/footer-section.css',
			'header-section'      => 'assets/css/module-css/header-section.css',
			'partner-section'      => 'assets/css/module-css/partner-section.css',
			'services-section'      => 'assets/css/module-css/services-section.css',
			'team-section'      => 'assets/css/module-css/team-section.css',
			'testimonial-section'      => 'assets/css/module-css/testimonial-section.css',
			'main-style'        => 'assets/css/style.css',
			'responsive'        => 'assets/css/responsive.css',
			'rtl'             => 'assets/css/rtl.css',
			'woocommerce'             => 'assets/css/woocommerce.css',
			
			
			//Temp
			//'color-panel'        => 'assets/temp/color-panel.css',
			
			
			
			//This is Theme Styles
			'error'             => 'assets/css/theme/error.css',
			'sidebar'         => 'assets/css/theme/sidebar.css',
			'tut'             => 'assets/css/theme/tut.css',
			'fixing'             => 'assets/css/theme/fixing.css',
			'gutenberg'             => 'assets/css/theme/gutenberg.css',
			
		);
		

		$styles = apply_filters( 'XOVEN/includes/classes/header_enqueue/styles', $styles );

		/**
		 * Enqueue the styles
		 *
		 * @var array
		 */
		foreach ( $styles as $name => $style ) {

			if ( strstr( $style, 'http' ) || strstr( $style, 'https' ) || strstr( $style, 'fonts.googleapis' ) ) {
				wp_enqueue_style( "xoven-{$name}", $style );
			} else {
				wp_enqueue_style( "xoven-{$name}", get_template_directory_uri() . '/' . $style );
			}
		}
		$options      = xoven_WSH()->option();
		$custom_style = '';

		wp_add_inline_style( 'color', $custom_style );

		$header_styles = self::header_styles(); 
		
		if ( $custom_font = $options->get('theme_custom_font') ) {
            $header_styles .= xoven_custom_fonts_load( $custom_font );
        }

		wp_add_inline_style( 'xoven-main-style', $header_styles );
	}

	/**
	 * Register custom fonts.
	 */
	public static function fonts_url() {
		$fonts_url = '';

		$font_families['Oswald']      = 'Oswald:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i';
		$font_families['Open Sans']      = 'Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i';

		$font_families = apply_filters( 'REXAR/includes/classes/header_enqueue/font_families', $font_families );

		$query_args = array(
			'family' => urlencode( implode( '|', $font_families ) ),
			'subset' => urlencode( 'latin,latin-ext' ),
		);

		$protocol  = is_ssl() ? 'https' : 'http';
		$fonts_url = add_query_arg( $query_args, $protocol . '://fonts.googleapis.com/css' );

		return esc_url_raw($fonts_url);
	}


	/**
	 * Add preconnect for Google Fonts.
	 *
	 * @since XOVEN 1.0
	 *
	 * @param array  $urls          URLs to print for resource hints.
	 * @param string $relation_type The relation type the URLs are printed.
	 *
	 * @return array $urls           URLs to print for resource hints.
	 */
	public static function resource_hints( $urls, $relation_type ) {
		if ( wp_style_is( 'xoven-fonts', 'queue' ) && 'preconnect' === $relation_type ) {
			$urls[] = array(
				'href' => 'https://fonts.gstatic.com',
				'crossorigin',
			);
		}

		return $urls;
	}

	/**
	 * header_styles
	 *
	 * @since XOVEN 1.0
	 *
	 * @param array $urls URLs to print for resource hints.
	 */
	public static function header_styles() {

		$data = \XOVEN\Includes\Classes\Common::instance()->data( 'blog' )->get();

		$options = xoven_WSH()->option();

		$styles = '';
		if ( $options->get( 'footer_top_button' ) ) :
			$styles .= "#topcontrol {
				background: " . $options->get( 'button_bg' ) . " none repeat scroll 0 0 !important;
				opacity: 0.5;

				color: " . $options->get( 'button_color' ) . " !important;

			}";

		endif;

		$settings = get_theme_mod( XOVEN_NAME . '_options-mods' );

		if ( $custom_font = xoven_set( $settings, 'theme_custom_font' ) ) {

			$styles .= apply_filters('xoven_redux_custom_fonts_load', $custom_font );


		}

		return $styles;
	}


}