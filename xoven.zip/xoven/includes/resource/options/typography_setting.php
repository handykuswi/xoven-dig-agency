<?php

return array(

    'title'         => esc_html__( 'Typography Settings', 'xoven' ),
    'id'            => 'typography_setting',
    'desc'          => '',
    'icon'          => 'el el-edit'
);