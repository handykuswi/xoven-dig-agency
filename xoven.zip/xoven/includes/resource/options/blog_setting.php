<?php

return array(
	'title'  => esc_html__( 'Blog Page Settings', 'xoven' ),
	'id'     => 'blog_setting',
	'desc'   => '',
	'icon'   => 'el el-indent-left',
	'fields' => array(
		array(
			'id'      => 'blog_source_type',
			'type'    => 'button_set',
			'title'   => esc_html__( 'Blog Source Type', 'xoven' ),
			'options' => array(
				'd' => esc_html__( 'Default', 'xoven' ),
				'e' => esc_html__( 'Elementor', 'xoven' ),
			),
			'default' => 'd',
		),
		array(
			'id'       => 'blog_elementor_template',
			'type'     => 'select',
			'title'    => __( 'Template', 'xoven' ),
			'data'     => 'posts',
			'args'     => [
				'post_type' => [ 'elementor_library' ],
				'posts_per_page'=> -1,
			],
			'required' => [ 'blog_source_type', '=', 'e' ],
		),

		array(
			'id'       => 'blog_default_st',
			'type'     => 'section',
			'title'    => esc_html__( 'Blog Default', 'xoven' ),
			'indent'   => true,
			'required' => [ 'blog_source_type', '=', 'd' ],
		),
		array(
			'id'      => 'blog_post_comments',
			'type'    => 'switch',
			'title'   => esc_html__( 'Show Post Comments', 'xoven' ),
			'desc'    => esc_html__( 'Enable to show post comments on posts listing', 'xoven' ),
			'default' => true,
		),

		array(
			'id'      => 'blog_post_author',
			'type'    => 'switch',
			'title'   => esc_html__( 'Show Author', 'xoven' ),
			'desc'    => esc_html__( 'Enable to show author on posts listing', 'xoven' ),
			'default' => true,
		),
		array(
			'id'      => 'blog_post_readmore',
			'type'    => 'switch',
			'title'   => esc_html__( 'Show Blog Read More', 'xoven' ),
			'desc'    => esc_html__( 'Enable to show post data on posts listing', 'xoven' ),
			'default' => true,
		),
		array(
		    'id'       => 'blog_post_readmoretext',
		    'type'     => 'text',
		    'title'    => esc_html__( 'Read More Text', 'xoven' ),
		    'desc'     => esc_html__( 'Enter Read More Text to Show.', 'xoven' ),
			'default'  => esc_html__( 'Read More', 'xoven' ),
	    ),
		array(
			'id'       => 'blog_default_ed',
			'type'     => 'section',
			'indent'   => false,
			'required' => [ 'blog_source_type', '=', 'd' ],
		),
	),
);