<?php

require_once get_template_directory() . '/includes/loader.php';

add_action( 'after_setup_theme', 'xoven_setup_theme' );
add_action( 'after_setup_theme', 'xoven_load_default_hooks' );


function xoven_setup_theme() {

	load_theme_textdomain( 'xoven', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );
	add_theme_support( 'custom-header' );
	add_theme_support( 'custom-background' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );


	// Set the default content width.
	$GLOBALS['content_width'] = 525;
	
	//Register image sizes
	add_image_size( 'xoven_370x260', 370, 260, true ); //'xoven_370x260 Our Projects'
	add_image_size( 'xoven_270x300', 270, 300, true ); //'xoven_270x300 Our Team'
	add_image_size( 'xoven_70x70', 70, 70, true ); //'xoven_70x70 Our Testimonials V2'
	add_image_size( 'xoven_370x240', 370, 240, true ); //'xoven_370x240 Latest News V2 '
	add_image_size( 'xoven_105x100', 105, 100, true ); //'xoven_105x100 Feature Services '
	add_image_size( 'xoven_270x120', 270, 120, true ); //'xoven_270x120 Our Industries '
	add_image_size( 'xoven_370x383', 370, 383, true ); //'xoven_370x383 Our Testimonials V3'
	add_image_size( 'xoven_330x300', 330, 300, true ); //'xoven_330x300 Our Services V2'
	add_image_size( 'xoven_975x530', 975, 530, true ); //'xoven_975x530 Our Projects V4'
	add_image_size( 'xoven_397x575', 397, 575, true ); //'xoven_397x575 Our Testimonials V4'
	add_image_size( 'xoven_370x270', 370, 270, true ); //'xoven_370x270 Our Services V3'
	add_image_size( 'xoven_270x390', 270, 390, true ); //'xoven_270x390 Our Projects V5'
	add_image_size( 'xoven_270x180', 370, 270, true ); //'xoven_270x180 Our projects V5'
	add_image_size( 'xoven_340x214', 340, 214, true ); //'xoven_340x214 Our Testimonials V6'
	add_image_size( 'xoven_340x240', 340, 240, true ); //'xoven_340x240 Our Team V3'
	add_image_size( 'xoven_270x430', 270, 430, true ); //'xoven_270x430 Portfolio Masonry'
	add_image_size( 'xoven_270x230', 270, 230, true ); //'xoven_270x230 Portfolio Masonry'
	add_image_size( 'xoven_400x327', 400, 327, true ); //'xoven_400x327 Blog List View'
	add_image_size( 'xoven_1170x400', 1170, 400, true ); //'xoven_1170x400 Our Blog'
	add_image_size( 'xoven_85x75', 85, 75, true ); //'xoven_85x75 Our Project Widget'
		
	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'main_menu' => esc_html__( 'Main Menu', 'xoven' ),
		'onepage_menu' => esc_html__( 'OnePage Menu', 'xoven' ),
		'home_rtl_menu' => esc_html__( 'Home RTL Menu', 'xoven' ),
	) );	
	
	
	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Add theme support for Custom Logo.
	add_theme_support( 'custom-logo', array(
		'width'      => 250,
		'height'     => 250,
		'flex-width' => true,
	) );

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_editor_style();
	add_action( 'admin_init', 'xoven_admin_init', 2000000 );
}



function xoven_gutenberg_editor_palette_styles() {
    add_theme_support( 'editor-color-palette', array(
        array(
            'name' => esc_html__( 'strong yellow', 'xoven' ),
            'slug' => 'strong-yellow',
            'color' => '#f7bd00',
        ),
        array(
            'name' => esc_html__( 'strong white', 'xoven' ),
            'slug' => 'strong-white',
            'color' => '#fff',
        ),
		array(
            'name' => esc_html__( 'light black', 'xoven' ),
            'slug' => 'light-black',
            'color' => '#242424',
        ),
        array(
            'name' => esc_html__( 'very light gray', 'xoven' ),
            'slug' => 'very-light-gray',
            'color' => '#797979',
        ),
        array(
            'name' => esc_html__( 'very dark black', 'xoven' ),
            'slug' => 'very-dark-black',
            'color' => '#000000',
        ),
    ) );
	
	add_theme_support( 'editor-font-sizes', array(
		array(
			'name' => esc_html__( 'Small', 'xoven' ),
			'size' => 10,
			'slug' => 'small'
		),
		array(
			'name' => esc_html__( 'Normal', 'xoven' ),
			'size' => 15,
			'slug' => 'normal'
		),
		array(
			'name' => esc_html__( 'Large', 'xoven' ),
			'size' => 24,
			'slug' => 'large'
		),
		array(
			'name' => esc_html__( 'Huge', 'xoven' ),
			'size' => 36,
			'slug' => 'huge'
		)
	) );
	
}
add_action( 'after_setup_theme', 'xoven_gutenberg_editor_palette_styles' );



/*---------- Enqueue Styles and Scripts ----------*/

function xoven_enqueue_scripts() {


	if( is_singular() ) wp_enqueue_script('comment-reply');
	
}
add_action( 'wp_enqueue_scripts', 'xoven_enqueue_scripts' );

/*---------- Enqueue styles and scripts ends ----------*/
/**
 * [xoven_widgets_init]
 *
 * @param  array $data [description]
 *
 * @return [type]       [description]
 */
function xoven_widgets_init() {

	global $wp_registered_sidebars;

	$theme_options = get_theme_mod( XOVEN_NAME . '_options-mods' );

	register_sidebar( array(
		'name'          => esc_html__( 'Default Sidebar', 'xoven' ),
		'id'            => 'default-sidebar',
		'description'   => esc_html__( 'Widgets in this area will be shown on the right-hand side.', 'xoven' ),
		'before_widget' => '<div id="%1$s" class="mrsidebar widget sidebar-widget single-sidebar %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="title"><h3>',
		'after_title'   => '</h3></div>',
	) );
	register_sidebar(array(
		'name' => esc_html__('Footer Widget', 'xoven'),
		'id' => 'footer-sidebar',
		'description' => esc_html__('Widgets in this area will be shown in Footer Area.', 'xoven'),
		'before_widget'=>'<div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 footer-column"><div id="%1$s" class="mr_footer footer-widget single-footer-widget %2$s">',
		'after_widget'=>'</div></div>',
		'before_title' => '<div class="title"><h3>',
		'after_title' => '</h3></div>'
	));
	if ( class_exists( '\Elementor\Plugin' )){

	register_sidebar(array(
		'name' => esc_html__('Services Widget', 'xoven'),
		'id' => 'service-sidebar',
		'description'   => esc_html__( 'Widgets in this area will be shown on the right-hand side.', 'xoven' ),
		'before_widget' => '<div id="%1$s" class="mrsidebar widget sidebar-widget single-sidebar %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="title"><h3>',
		'after_title'   => '</h3></div>',
	));
	}
	register_sidebar(array(
	  'name' => esc_html__( 'Blog Listing', 'xoven' ),
	  'id' => 'blog-sidebar',
	  'description'   => esc_html__( 'Widgets in this area will be shown on the right-hand side.', 'xoven' ),
		'before_widget' => '<div id="%1$s" class="mrsidebar widget sidebar-widget single-sidebar %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="title"><h3>',
		'after_title'   => '</h3></div>',
	));
	if ( ! is_object( xoven_WSH() ) ) {
		return;
	}

	$sidebars = xoven_set( $theme_options, 'custom_sidebar_name' );

	foreach ( array_filter( (array) $sidebars ) as $sidebar ) {

		if ( xoven_set( $sidebar, 'topcopy' ) ) {
			continue;
		}

		$name = $sidebar;
		if ( ! $name ) {
			continue;
		}
		$slug = str_replace( ' ', '_', $name );

		register_sidebar( array(
			'name'          => $name,
			'id'            => sanitize_title( $slug ),
			'before_widget' => '<div id="%1$s" class="%2$s widget ">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );
	}

	update_option( 'wp_registered_sidebars', $wp_registered_sidebars );
}

add_action( 'widgets_init', 'xoven_widgets_init' );

/**
 * [xoven_admin_init]
 *
 * @param  array $data [description]
 *
 * @return [type]       [description]
 */


function xoven_admin_init() {
	remove_action( 'admin_notices', array( 'ReduxFramework', '_admin_notices' ), 99 );
}

/**
 * [xoven_set description]
 *
 * @param  array $data [description]
 *
 * @return [type]       [description]
 */
if ( ! function_exists( 'xoven_set' ) ) {
	function xoven_set( $var, $key, $def = '' ) {
		//if( ! $var ) return false;

		if ( is_object( $var ) && isset( $var->$key ) ) {
			return $var->$key;
		} elseif ( is_array( $var ) && isset( $var[ $key ] ) ) {
			return $var[ $key ];
		} elseif ( $def ) {
			return $def;
		} else {
			return false;
		}
	}
}
function xoven_add_editor_styles() {
    add_editor_style( 'editor-style.css' );
}
add_action( 'admin_init', 'xoven_add_editor_styles' );

// Add specific CSS class by filter.
$options = xoven_WSH()->option(); 
if( xoven_set($options, 'boxed_wrapper') ){

add_filter( 'body_class', function( $classes ) {
    $classes[] = 'boxed_wrapper';
    return $classes;
} );
}

/*---------- Enqueue Styles and Scripts ----------*/