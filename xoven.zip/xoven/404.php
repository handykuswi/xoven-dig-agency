<?php
/**
 * 404 page file
 *
 * @package    WordPress
 * @subpackage Xoven
 * @author     Theme Kalia <admin@theme-kalia.com>
 * @version    1.0
 */

$text = sprintf(__('It seems we can\'t find what you\'re looking for. Perhaps searching can help or go back to <a href="%s">Homepage</a>', 'xoven'), esc_html(home_url('/')));
$error_page_img    = $options->get( 'error_page_image' );
$error_page_img    = xoven_set( $error_page_img, 'url', XOVEN_URI . 'assets/images/resource/404.png' );
$allowed_html = wp_kses_allowed_html( 'post' );
?>
<?php get_header();
$data = \XOVEN\Includes\Classes\Common::instance()->data( '404' )->get();

$options = xoven_WSH()->option();
if ( class_exists( '\Elementor\Plugin' ) AND $data->get( 'tpl-type' ) == 'e' AND $data->get( 'tpl-elementor' ) ) {
	echo Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $data->get( 'tpl-elementor' ) );
} else {
	?>

<?php if ( $data->get( 'enable_banner' ) ) : ?>
	
	<!--Start breadcrumb area-->     
<?php if ( $data->get( 'banner' ) ) : ?>
<section class="breadcrumb-area two">
    <div class="breadcrumb-area-bg" style="background-image: url(<?php echo esc_url( $data->get( 'banner' ) ); ?>);"></div>
<?php else : ?>	

<section class="breadcrumb-area two">
    <div class="breadcrumb-area-bg" style="background-image: url(<?php echo esc_url(get_template_directory_uri().'/assets/images/breadcrumb/breadcrumb-1.jpg');?>);"></div>
<?php endif; ?>	

    <div class="breadcrumb-social-link">
        <ul class="clearfix">
            <li class="wow slideInUp" data-wow-delay="500ms" data-wow-duration="1000ms">
                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a> 
            </li>
            <li class="wow slideInUp" data-wow-delay="700ms" data-wow-duration="2000ms">
                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a> 
            </li>
            <li class="wow slideInUp" data-wow-delay="900ms" data-wow-duration="1000ms">
                <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
            </li>
            <li class="wow slideInUp" data-wow-delay="1100ms" data-wow-duration="2100ms">
                <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a> 
            </li>
        </ul>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="inner-content text-center">
                    <div class="title paroller">
                       <h2><?php if( $data->get( 'title' ) ) echo wp_kses( $data->get( 'title' ), true ); else( wp_title( '' ) ); ?></h2>
                    </div>
                    <div class="breadcrumb-menu">
                        <ul>
                            <?php echo xoven_the_breadcrumb(); ?>
                        </ul>    
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End breadcrumb area-->

<?php endif; ?>
	
    <div class="error-section">
        <div class="auto-container">
            <div class="text-center">     
                <div class="content">
				
					<figure class="error-image p_relative d_block mb_70">
				<img src="<?php echo esc_url(get_template_directory_uri().'/assets/images/error.png');?>" alt="<?php echo wp_kses( $options->get( '404_page_text'), $allowed_html ); ?>">
			</figure>
				
				<?php if($options->get('404_page_title' ) ): ?>	
				
				<h2><?php echo wp_kses( $options->get( '404_title'), $allowed_html ); ?></h2>
				<?php else: ?>
				<h2><?php esc_html_e( '404 - Page Not Found', 'xoven' ); ?></h2>
				<?php endif; ?>
				
				<?php if($options->get('404_page_text' ) ): ?>
				<h3><?php echo wp_kses( $options->get( '404_page_text'), $allowed_html ); ?></h3>
				<?php else: ?>	
				<h3><?php esc_html_e( 'The page you are looking for does not exist.', 'xoven' ); ?></h3>
				<?php endif; ?>	
				
				<?php if(!$options->get('back_home_btn' ) ): ?>		
				<?php if($options->get('back_home_btn_label' ) ): ?>
				
				<div class="btn-box clearfix">
				<a class="btn-one aos-init aos-animate" data-aos="fade-up" data-aos-easing="linear" data-aos-duration="700" href="<?php echo( home_url( '/' ) ); ?>"><?php echo wp_kses( $options->get( 'back_home_btn_label'), $allowed_html ); ?></a>
				</div>
				
				<?php else: ?>
				
				<div class="btn-box clearfix">
				<a class="btn-one aos-init aos-animate" data-aos="fade-up" data-aos-easing="linear" data-aos-duration="700" href="<?php echo( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to Home', 'xoven' ); ?></a>
				</div>
				
				<?php endif; ?>		
				<?php endif; ?>
					 
                </div>                
            </div>
        </div>
    </div>
     
<?php
}
get_footer(); ?>
